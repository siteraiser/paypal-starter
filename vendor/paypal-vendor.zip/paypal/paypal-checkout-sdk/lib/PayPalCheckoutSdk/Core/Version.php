<?php

namespace PayPalCheckoutSdk\Core;

class Version
{
    const VERSION = "1.0.1";
}
